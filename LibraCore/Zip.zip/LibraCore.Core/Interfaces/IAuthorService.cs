﻿using LibraCore.Infrastructure.Data.Entities;
using LibraCore.ViewModels.Author;

namespace LibraCore.Services.Interfaces
{
    public interface IAuthorService
    {
        Task<IEnumerable<AuthorViewModel>> GetAllAuthorsOrderedByNameAsync();

        Task AddAuthorAsync(AuthorInputModel model);

        Task SoftDeleteAuthorAsync(Guid id);

        Task<AuthorViewModel?> GetAuthorByIdAsync(Guid id);
    }
}
